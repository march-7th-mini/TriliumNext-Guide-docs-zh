/* ============================================================
 *   帮助文档中文版跳转补丁 V3
 *   原理：猴子补丁 NoteContext.prototype.setNote，
 *         拦截「contextual-help 分屏」与「快速编辑弹窗(_popup-editor)」
 *         中对英文 _help_* 笔记的打开，自动改为打开对应中文版。
 *   标签：#run=frontendStartup
 *   类型：JS Frontend
 *
 *   V2 用轮询 api.getNoteContexts() 只能覆盖 contextual-help 分屏。
 *   快速编辑弹窗(PopupEditor)使用独立 NoteContext(ntxId="_popup-editor")，
 *   不在 tabManager 中、getNoteContexts() 看不到，V2 对弹窗无效。
 *   Trilium 中所有「打开笔记」最终都走 NoteContext.prototype.setNote，
 *   V3 直接补丁 setNote，统一覆盖分屏与弹窗，且在加载英文前就改成中文（无闪屏）。
 * ============================================================ */

(function () {
  'use strict';

  if (window.__chineseHelpRedirectPatchV3) return;
  window.__chineseHelpRedirectPatchV3 = true;

  const DEBUG = false;

  // 英文 _help_* noteId -> 中文 noteId（找不到也存 null，本会话内不再重复查询）
  const chineseCache = new Map();
  const inflight = new Map();

  // 命中即跳转的 NoteContext
  const REDIRECT_NTX_IDS = new Set(['_popup-editor']);       // 快速编辑弹窗
  const REDIRECT_VIEW_MODES = new Set(['contextual-help']);  // ? 帮助分屏

  function log(...args) {
    if (DEBUG) console.log('[帮助跳转V3]', ...args);
  }

  function isEnglishHelpNoteId(noteId) {
    return typeof noteId === 'string' && noteId.startsWith('_help_');
  }

  // setNote 的第一个参数可能是 noteId，也可能是 "root/.../noteId" 路径，取末段即 noteId
  function extractNoteId(inputNotePath) {
    if (typeof inputNotePath !== 'string' || !inputNotePath) return null;
    const seg = inputNotePath.split('/').pop();
    return seg || null;
  }

  function shouldRedirect(self, opts) {
    if (self && self.ntxId && REDIRECT_NTX_IDS.has(self.ntxId)) return true;
    const vm = opts && opts.viewScope && opts.viewScope.viewMode;
    return !!(vm && REDIRECT_VIEW_MODES.has(vm));
  }

  // 通过 #originalHelpNoteId 标签查找中文版
  async function findChinese(englishNoteId) {
    if (!englishNoteId) return null;
    if (chineseCache.has(englishNoteId)) return chineseCache.get(englishNoteId);
    if (inflight.has(englishNoteId)) return inflight.get(englishNoteId);

    const p = (async () => {
      try {
        const query = '#originalHelpNoteId = "' + englishNoteId.replace(/"/g, '\\"') + '"';
        const results = await api.searchForNotes(query);
        const chineseId = results && results[0] ? results[0].noteId : null;
        chineseCache.set(englishNoteId, chineseId);
        return chineseId;
      } catch (e) {
        log('查找中文版失败:', englishNoteId, (e && e.message) || e);
        chineseCache.set(englishNoteId, null);
        return null;
      } finally {
        inflight.delete(englishNoteId);
      }
    })();

    inflight.set(englishNoteId, p);
    return p;
  }

  // 装载阶段兜底：把补丁安装前已经打开的英文帮助分屏补跳一次
  async function sweepOnce() {
    try {
      const contexts = api.getNoteContexts ? api.getNoteContexts() : [];
      for (const ctx of contexts) {
        const noteId = ctx && ctx.note && ctx.note.noteId;
        if (!isEnglishHelpNoteId(noteId)) continue;
        const vm = ctx.viewScope && ctx.viewScope.viewMode;
        if (vm !== 'contextual-help') continue;

        const chineseId = await findChinese(noteId);
        if (!chineseId) continue;
        // 查询期间用户可能已切换，避免跳到旧目标
        if (!ctx.note || ctx.note.noteId !== noteId) continue;
        log('sweep 跳转:', noteId, '=>', chineseId);
        await ctx.setNote(chineseId, { viewScope: { viewMode: 'contextual-help' } });
      }
    } catch (e) {
      log('sweep 出错:', (e && e.message) || e);
    }
  }

  function install() {
    let ctx = null;
    try { ctx = api.getActiveContext && api.getActiveContext(); } catch (e) {}
    if (!ctx) {
      try {
        const arr = api.getNoteContexts && api.getNoteContexts();
        ctx = (arr && arr[0]) || null;
      } catch (e) {}
    }

    const Proto = ctx && ctx.constructor && ctx.constructor.prototype;
    if (!Proto) {
      log('尚未拿到 NoteContext，稍后重试');
      return false;
    }
    if (Proto.__chineseHelpPatched) {
      log('已补丁');
      return true;
    }
    const origSetNote = Proto.setNote;
    if (typeof origSetNote !== 'function') {
      log('setNote 非函数，放弃');
      return true;
    }

    Proto.setNote = async function (inputNotePath, opts) {
      try {
        if (inputNotePath && shouldRedirect(this, opts)) {
          const noteId = extractNoteId(inputNotePath);
          if (isEnglishHelpNoteId(noteId)) {
            const chineseId = await findChinese(noteId);
            if (chineseId) {
              log('跳转中文版:', noteId, '=>', chineseId, 'ntx=' + (this && this.ntxId));
              return origSetNote.call(this, chineseId, opts);
            }
            log('未找到中文版，保持英文:', noteId);
          }
        }
      } catch (e) {
        log('跳转异常，回退原行为:', (e && e.message) || e);
      }
      return origSetNote.call(this, inputNotePath, opts);
    };
    Proto.__chineseHelpPatched = true;
    log('补丁安装完成');
    return true;
  }

  function start() {
    log('帮助文档中文版跳转补丁 V3 启动');
    let tries = 0;
    const tryInstall = () => {
      if (install()) {
        // 补丁装好后，sweep 几次补跳已打开的英文帮助分屏
        window.setTimeout(sweepOnce, 400);
        window.setTimeout(sweepOnce, 1500);
        window.setTimeout(sweepOnce, 3500);
      } else if (++tries < 20) {
        window.setTimeout(tryInstall, 500);
      } else {
        log('重试次数耗尽，放弃');
      }
    };
    tryInstall();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
